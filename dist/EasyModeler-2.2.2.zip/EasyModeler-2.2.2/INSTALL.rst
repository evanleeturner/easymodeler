Install EasyModel by running:

easy_install EasyODE